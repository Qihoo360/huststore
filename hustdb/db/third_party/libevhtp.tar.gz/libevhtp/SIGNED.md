##### Signed by https://keybase.io/strcpy
```
-----BEGIN PGP SIGNATURE-----
Version: GnuPG v1

iQEcBAABAgAGBQJVC7HUAAoJEPIKXr0GpbbCZ1wIAJ5MwoT3jggOf6d+MBfLJb6Z
n9lL8B+MAVzDL5u0beZzY9AFPnHn+Npj1rf49SOrbiGYgDPqOJPk7ZrxNv+wAFGz
m6xiiOWUta0qaTIS1RgnXih0WOcir+5lm/5DuWlW4a7obUs30IEZzsvUqMVsxcX9
70CFuvJBwTzf1NAMTpzGweZ/00yRVMacBO56aWMKLyHT7at3rMFRm8TSBBmvnO6y
zFmprtPDQpV7GgAh5PTspfPkT4dLmfwgCTvgC+hoAef/6+XtIfESl0EdWZTjg3OO
ZWukfeoCvIBXAxmGd/ns/mahLM2jFDRoGL09LyezrGUQvx6A8t2PWUHYsExnD1g=
=h8Wj
-----END PGP SIGNATURE-----

```

<!-- END SIGNATURES -->

### Begin signed statement 

#### Expect

```
size    exec  file                       contents                                                                                                                         
              ./                                                                                                                                                          
173             .gitignore               372447fe4ebc48d242af7873ca6e8e18d73bee6a21525d7898c82d67dda48728                                                                 
12269           CMakeLists.txt           b4d807ff26d14ebeaa27516a0923fb43bc709b07c1a8837538f3bb8c877b679f                                                                 
                CMakeModules/                                                                                                                                             
3926              AddOptions.cmake       b89e00b3a04af81f1d7fad2ad9ec09e43d227a8740e74c6af38ff320e4bc7798                                                                 
1213              BaseConfig.cmake       b69f6aab9039f6dbdc5e337b2ab2bac3d58956097a3685be37568be6f9b64c18                                                                 
1349              FindLibEvent.cmake     d6ded937cc2f557531e4b7232158a22bec67fc4f3e7ea6525a64a52ab9b04788                                                                 
3770              UseCompVer.cmake       e5b4052ddb6aa19057f2c4e09dcd3da23c2d9698941b31f9b31f548f7f8adcf7                                                                 
5304              UseDebugSymbols.cmake  aa013ac37e5c61845739dbe2852d637a4542abef4edae89b8a043c1e83cde211                                                                 
33495           ChangeLog                2a02b057b18132bb36bfb29ab32a6e38d7530c2cf7f7b63ea6e0c2e23fb4d40c                                                                 
69989           Doxyfile                 80cee7da0b443cb608470527dfb3eb25caf8318deeb8ba1734aeafadc9871552                                                                 
1781            LICENSE                  b013218ca11124c57d295516987989a3d7d8dcf17bb22b0923ddf5eb9982b3c5                                                                 
5308            README.markdown          737a395d07c1c4f80bfc00fca84b2a5ddc844d4ea8695ee1819105e59262b942                                                                 
                build/                                                                                                                                                    
0                 placeholder            e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855                                                                 
                compat/                                                                                                                                                   
                  sys/                                                                                                                                                    
16674               queue.h.in           f5b69cf714d6c0bccb69c3a3b66839634ea8be6905b0dd141613889d155b489f                                                                 
74192               tree.h.in            ae4dad3d8437c922d215f15d8dcba74fa60b5b43851bdd12a6da652471eee43d                                                                 
590             evhtp-config.h.in        d3090a15e212f00ede0dac030481eb41a33bfd30934e7b5640c8a12332057a75                                                                 
720             evhtp-internal.h         bf88199b54863f56a58ad7dcb249bb967a7dfaa6d58567c9fd10d3e73e15d4b6                                                                 
116275          evhtp.c                  4fd2c70a560d8a5fa854ae004dd8dd799032ac8c59044aaa538179035c219e8a                                                                 
42916           evhtp.h                  718f3957ad317937b737c58cc268a10b8069067e1091292e4709369ff551b1a8                                                                 
287             evhtp.pc.in              0d68fca6310508d446ebc8ee963c97136772ea3e69a00123968f0b613937ecc7                                                                 
1507            evhtp_numtoa.c           17c99ca11204b848accd5aaf3aa17f3ffa81927bb727c7b1e2e2f36293e5a4a8                                                                 
876             evhtp_numtoa.h           8ac8153c37984ea6082702ae9e715af989bc7260455a6ec67e84c92422fab005                                                                 
7073            evthr.c                  0d68eef07fd63a8b3a4e89d083068ffa9c1d7a84cd469ed5b98a708f15cdd34b                                                                 
1643            evthr.h                  bf1ea48887450deb3b9f1e623c01d90a42eb7bf1f63cd5d087d597fa88079d94                                                                 
                examples/                                                                                                                                                 
18422             test.c                 e42e9425289f5852a4b7373a848e1e58bb54cdd83d77181c29de89e1c3f6702b                                                                 
846               test_basic.c           302e23d3475099f9efd9c22b19a9f17463baf9c91f93cdd4bb5732b6c1f2df2e                                                                 
2060              test_client.c          9d06f74af2272a7f7cc3a0fc03e5ec7b9f7bd4c7c7f64aaee40532043100cb49                                                                 
11962             test_htparse.c         4e2e659ae2be92e1cf9decb9a42040e7a2ee6d2efd41ec29f4c1a0feb7971e7b                                                                 
3545              test_proxy.c           7ca2c2fda2755457ab15221165ec8a6f59128260b58bf6a001a173e91597864e                                                                 
7533              test_query.c           29c3092d9d0a54ed36b505ca5d38444bd10562cfd746366989abdec3f19095c5                                                                 
1317              test_vhost.c           fe1ef3b75a10a043ba8c827717240bfabe860b4880e5c5b3e165cbd2127b85ef                                                                 
10340             thread_design.c        0991b37d7f2be57ca696dccb5728e61b51b66aece0d2e125fbefcf0a4cbcc6ff                                                                 
67336           htparse.c                d954a62926dce13b92439177232658144daa27ea406a00a291e10e563599227e                                                                 
3801            htparse.h                fbe06e8488248048baac677c7953ee87763c310a8c65cf73858cceff3f78198f                                                                 
                oniguruma/                                                                                                                                                
41                AUTHORS                d74e190700c96963a9a4d883c2780d6f0c9a035f9d84d21a7ff977bd0bef3b54                                                                 
1881              CMakeLists.txt         c979eaa21f6cc50bb38432305166fc08e969866c7dc59df3f326d498d00645ed                                                                 
1426              COPYING                0367dd7457d2499db8d1619ddd34223772d87f64d3db6aef9fab27753c0d0eda                                                                 
104851            HISTORY                2326065d34bf4b93fcd94ee81fd4cfd37c3c84e32eed23c2024cae7a019eb28f                                                                 
9478              INSTALL                4008daba19745ef700e8a69d160c8cc74347b8662c4285b5f943a66bc6e696a6                                                                 
2819              Makefile.am            61856fc2c97c84fd099431f6fe90328a467bcf0b54dc6aff616f4548e1018882                                                                 
64662             Makefile.in            6514edd957546aa8758b4c7b1e49a22e46de87e704b4086796f2fe7eb8ee8aa1                                                                 
5824              README                 dd126c9730f67218d294dc41bc27e52634be4e62e3cfbd70222fcbe342ec8f49                                                                 
5906              README.ja              9c8ae9854d7a686d6925d3f40c3d58d6fa96393cab7f81db3e730d8a70a02701|4350eb3d6ca4027e3719e1d30d330217503793dd2b7faf36cc312d8efb00bed7
1030              config.h.in            663ad7972d7d51a148097130e86c10875a2e9478938e30049d974ba3d69cbfe9                                                                 
                  enc/                                                                                                                                                    
2408                ascii.c              62a20e8eabacf7e9673eda63428194e8700f467f55a2264701ae1f30c95bf4d8                                                                 
5438                big5.c               b9281459f1f30614b5cdbd758683e86211967b1d8b1d04d826fe9932caf0c914                                                                 
8427                cp1251.c             698af66ad00f662c28bd88e798d58b1844c2ebdc2c7544e8eb7621afbfcda65c                                                                 
7212                euc_jp.c             a0c90ad9a2e17940621f331fb674082ed3adc8632ecbd79f4cb10aeb987eb31f                                                                 
5169                euc_kr.c             88940a071cbc08cb98c8f6520871b80f2bab19d8f7ea4bb97bccd760c3af4987                                                                 
4391                euc_tw.c             2a50ad60a1198a9a520dee5f78f4bd5aae5268f5c1ba0851c3239339f8fa5c56                                                                 
12623               gb18030.c            158c7021e2cb3ac419d88208679dd45d68cf667531fa4aba12c45c2e610827b7                                                                 
8759                iso8859_1.c          0a96294d835c4e779af6abbd781f961c607e3069c725ea06db7697c0896a22fd                                                                 
9061                iso8859_10.c         cfaee581e23415fea0ead784764ee1b068258f7b17866b779e5699d84cc09bbe                                                                 
4700                iso8859_11.c         fb99147fcad49a640089ac0432e096f893550646bc4793dcf76f80ee5dc0b3ed                                                                 
8936                iso8859_13.c         b83a37f4affcbc155818f674c759029092ff5c1afa35dabda5c42bacdc659743                                                                 
9118                iso8859_14.c         694d310eef7b2d9302da4e413d66c4be60ca2c92bad0bd3c92ff950b8714143c                                                                 
9090                iso8859_15.c         46f71d3e79df7b2c1f35b4a88a2fe8ed0e9bafcafde517eea8bf9ac113530c11                                                                 
9064                iso8859_16.c         4f895f1f3e39a5feeed493879952ed59023a026ce5203ab797e37a8c79e620cf                                                                 
9032                iso8859_2.c          f814e36f349647388d5c1164abff03286eb2959a5ac54a466943ce4507426122                                                                 
9017                iso8859_3.c          993248f9e139973c7c122e17e2a961771f2adb0e80f83d05b72887a533bd211b                                                                 
9068                iso8859_4.c          bde4dcd84715b29654bd6af041776472f4573b2e835f34f79ce6dc0b9f92bd70                                                                 
8788                iso8859_5.c          455036deb66b1f46324044d3c0444aeaccd7aa0a6cd6c09ba91db688577474b5                                                                 
4693                iso8859_6.c          f608d8d17f929ba2cbe147769391a24dad26dc828696509b5438cdf12dae3ca2                                                                 
8702                iso8859_7.c          e087979a15be34232ff778f64457058a769fe5a17e0d752c6b904c6c713f8bce                                                                 
4693                iso8859_8.c          5e921ad74752363d0fff3c6d451393bff381dd342044a7256a9403bff2216559                                                                 
8970                iso8859_9.c          cea4207ea1fea951fd04d7ce77d2636244febf0255f074b54c6c3870d8804f66                                                                 
9267                koi8.c               0b8b9aabafed1f7df7559a097582cc736332870810dd95c5c43215f28aa68e92                                                                 
8623                koi8_r.c             ebd883250c1074d1290c8841d26c77724cb37bee5d66317af134dd9e2e01fa5b                                                                 
28613               mktable.c            278b62506987e040c83d76b9719a3806d83ad8011343bfcc5f77e1ea4f3bb72f                                                                 
8259                sjis.c               58bf75d8271f35baabba3e0dff63931daafa4a5d5e5d0a694c8216329032e8ad                                                                 
238107              unicode.c            83dc72f52eca615214c5260505a2917cbd0a79c7efe9002a6c269ee86e985d67                                                                 
6208                utf16_be.c           7536dafcc03c2f6b2dfb09907a7e57a0df6a79e6c321fc99feb4b9cf3475eda8                                                                 
6254                utf16_le.c           6f571e6351cbf5cbdc83f96cb371560ca76cda91c48d4bda3addb5fdaebca83e                                                                 
5083                utf32_be.c           f7e51559eb0d03f80e94e5c14dc359315ce91d33a26c1ac6b4a6712c7309301f                                                                 
5116                utf32_le.c           fb5367d3be48c7f9b30108db8619c30ae1f43938a19780924483957e54bdf1da                                                                 
8281                utf8.c               1ae263d2c475b46c4946b3caa8026ecdd6bfff2792555a43388cc62e6f5a421e                                                                 
1407              onig-config.in         d4f03d9e6b851fcc11ecf625aadf1248c9da4db9ddb9a7f538f51347a752616a                                                                 
3429              oniggnu.h              9b105f489f39e0e3c7f8a134c1876aa06ab91ef5abf5bf28edd3da29ff82a9f3                                                                 
5753              onigposix.h            6923ff3279c303e97a3509ed94f8499ab0fbec56d241afd79e1a853b3abfff32                                                                 
36363             oniguruma.h            49d7362f079ebc3730b448e553e7d84cabcee2cd7af0ae712c16ff54db4d571b                                                                 
144310            regcomp.c              0ba02e07f84c849b712a7cee0dbe4df87c06115d6ddbf85a270938f62bfc967c                                                                 
27673             regenc.c               4aa13ad79a29fb352851621fcefb70fbf0bf78254fcbe20ef1d655005165a86b                                                                 
8995              regenc.h               d2569a176cdcab3a720b73375ecb54056b9078ec3f3c397a12c9218a57dae7cc                                                                 
12127             regerror.c             cb3153290fb35b68daf75ac800ea5e02dca73f6289f6bed7d2adc119e75bbb09                                                                 
92706             regexec.c              85ef2a2017f40d31d9b106351eb38f2aa5d1d082bdacc3c4624dc61b43be0647                                                                 
5961              regext.c               a36080ca9604c3bed612e0bbd433cfcc38b097a0cc5acccfec82105a57a60a94                                                                 
4606              reggnu.c               d2f863bb05f1216d2bd5eb57ddb7e8d178fdbbbce12e89d93f708ba6e37edbd2                                                                 
29044             regint.h               23c3975f371908ac114bd79264109b6f3f8357b6fc83ba3183229b1f500304b0                                                                 
124477            regparse.c             79d83acd99ce212df1d610ed8dbea00017bf60a105a02e5a8ab58a3f1570cc98                                                                 
12158             regparse.h             c8480f242f865552d947a949383b6579d496839bbc8dfbd1a391460b43e37513                                                                 
3630              regposerr.c            853945b9695209ab73f61396a9341ebd334af59ed4a142ecca2f807a12b78e42                                                                 
10840             regposix.c             be43f47c3e13c2674fc39505765959fdc7ec961ceb31c4cea74c7260be517aa7                                                                 
11381             regsyntax.c            66e05410c16eb32806847e68faed7570a8acfac929cf13d399d1096c5e28668f                                                                 
2884              regtrav.c              799d2e82006486abf6e98683b79bc8d3c8febb525dd87e993b0d010d4a1e2ac5                                                                 
2116              regversion.c           eac3ffb78255e00142d72d2f79049efdab7f78a01fc722d5ad6b619f326231c6                                                                 
                  sample/                                                                                                                                                 
596                 Makefile.am          d030dcd544ad5d3aa5495d8f29e85fcaccddd1378598d220708a63b1253eec35                                                                 
15992               Makefile.in          f9d0c0342d1a1fb09aa5cae2256c3810ac8cdf99f286496b916f35b6186dc7ef                                                                 
3530                crnl.c               168a89366cffbac7727716a22f1ec6e7ed0faa3759b5fad5f16f55353fdcc115                                                                 
9755                encode.c             a77d8264fec223b64193639aba189ae85cc369662f19630ee753543685f219eb                                                                 
2680                listcap.c            e45e0dc19dd8378c0b561106014261c337f1bf8e4ab5646a1cbc4cfc85568dc3                                                                 
1893                names.c              29842695e33f18219e1bc82212815e8f7cdcd92f6cffb29ee1fb43180a6eca99                                                                 
2327                posix.c              dbee9148884b62c2866d3108c0ad9af3f855a7b5058b47415531eff1f6a0f536                                                                 
1361                simple.c             ccb8e23f98df3ab83c3c0574ef59f3bac46d2ce7b7527e8ae5199a0d4e5fd522                                                                 
2167                sql.c                d5f5221557f6f1ce631a278e52485043115097daa235456329b1977e1f0e7478                                                                 
1801                syntax.c             131f74f8fe66978d6e5c8cfb89467d20583a5320a53f3bcb1279cbde37a47169                                                                 
11025             st.c                   87ad07cac050af7d3e5dd2ed3be50dedda8886695c889cee8710900746e14eb3                                                                 
1648              st.h                   8abe8d7952fa49cc1a021c85609474a1c5570674287404c95ab8f23c98b17bb3                                                                 
27942             testc.c                d2594d1369b3c73e7def01d23c75ac808a2463fa4aee7f73fcd8e5b68c8e0ee0|3e948438abafa03feda79d5dbfd01acedb8498c7e0d3008b153de68457b22d69
71370             testu.c                38b3b842afe0e1d80765c78c1fc1adfbfda381163c85267da1a8816feee7adb6                                                                 
                  win32/                                                                                                                                                  
7246                Makefile             e1ec44a22c546cefe53c5809eda594b768829f0847de0dc748e5f108a7cd61c7|6354cc21dd799689aa20b7927fe9b7910bc7ef6a5802fcf906b24b7b9829ed09
2033                config.h             dc26c6e27c03e980a9dbd853296e219b6a007614780d50af64ec48266b632468|06de45495bc5e68ede1bebf4cf9efbb477ee4dce9889e8a889d6355c40285d0d
28801               testc.c              3208bf7b05caadfc3aaa59dead98551a656bb8e7181aaed3e0d2c322b02abd6d|b9d8a129156ca32fff146a385b94a0cbd78306827be800962ca044c25826966a
70035           zimg_vs_nginx.png        274b9e87a8c89d2139564937f143e253830cebf121423e8c8fa9d4d7b7da6eb4|9db9594e8a78c04a34c35b419271d8d908e198f0c543eb1b9b462d6224cf1e49
```

#### Ignore

```
/SIGNED.md
```

#### Presets

```
git      # ignore .git and anything as described by .gitignore files
dropbox  # ignore .dropbox-cache and other Dropbox-related files    
kb       # ignore anything as described by .kbignore files          
```

<!-- summarize version = 0.0.9 -->

### End signed statement

<hr>

#### Notes

With keybase you can sign any directory's contents, whether it's a git repo,
source code distribution, or a personal documents folder. It aims to replace the drudgery of:

  1. comparing a zipped file to a detached statement
  2. downloading a public key
  3. confirming it is in fact the author's by reviewing public statements they've made, using it

All in one simple command:

```bash
keybase dir verify
```

There are lots of options, including assertions for automating your checks.

For more info, check out https://keybase.io/docs/command_line/code_signing